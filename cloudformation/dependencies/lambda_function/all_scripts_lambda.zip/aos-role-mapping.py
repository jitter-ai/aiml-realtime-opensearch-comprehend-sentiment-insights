import json
import os
import requests
from requests_aws4auth import AWS4Auth
import boto3
import sys
from opensearchpy import OpenSearch, RequestsHttpConnection

class STSClient:
    def __init__(self, region):
        self.client = boto3.client('sts', region_name=region)

    def assume_role(self, role_arn, session_name, duration_seconds=3600, external_id=None, serial_number=None, token_code=None):
        """Assumes an AWS role and returns temporary security credentials."""
        assume_role_params = {
            'RoleArn': role_arn,
            'RoleSessionName': session_name,
            'DurationSeconds': duration_seconds,
        }

        # Add optional params only if they exist
        if external_id:
            assume_role_params['ExternalId'] = external_id
        if serial_number and token_code:
            assume_role_params['SerialNumber'] = serial_number
            assume_role_params['TokenCode'] = token_code

        assumed_role = self.client.assume_role(**assume_role_params)
        return assumed_role['Credentials']

class OpenSearchClient:
    def __init__(self, domain_endpoint, awsauth):
        self.client = OpenSearch(
            hosts=[{'host': domain_endpoint, 'port': 443}],
            http_auth=awsauth,
            use_ssl=True,
            verify_certs=True,
            connection_class=RequestsHttpConnection
        )

    def get_current_roles(self, role_name):
        """Fetch current role mappings, if role not found return an empty list."""
        try:
            response = self.client.security.get_role_mapping(role=role_name)
            return response.get(role_name, {}).get('backend_roles', [])
        except KeyError:
            return []  # Default to empty list if role is not found

    def create_role_mapping(self, role_name, updated_roles):
        """Create or update role mapping in OpenSearch."""
        body = {
            "backend_roles": updated_roles,
            "hosts": [],
            "users": []
        }

        response = self.client.security.create_role_mapping(
            role=role_name,
            body=body
        )
        return response

    def get_all_roles(self):
        """Get all roles in OpenSearch."""
        return self.client.security.get_roles()

class RoleMapper:
    def __init__(self, opensearch_client):
        self.opensearch_client = opensearch_client

    def map_roles(self, role_name, arn_roles):
        """Map multiple ARN roles to a given role."""
        existing_roles = self.opensearch_client.get_current_roles(role_name)
        updated_roles = list(set(existing_roles + arn_roles))  # Ensure roles are unique
        response = self.opensearch_client.create_role_mapping(role_name, updated_roles)
        return response, updated_roles

class EnvironmentConfig:
    def __init__(self):
        self.region = os.getenv('REGION')
        self.opensearch_endpoint = os.getenv('OPENSEARCH_ENDPOINT')
        self.role_map1 = os.getenv('ROLE_MAP1')
        self.arn_roles = [self.role_map1] + [os.getenv(f'ROLE_MAP{i}') for i in range(2, 5) if os.getenv(f'ROLE_MAP{i}')]

        # Only print critical environment variables, skip PIPELINE_ARN_ROLES if not set
        print(f"REGION: {self.region}")
        print(f"OPENSEARCH_ENDPOINT: {self.opensearch_endpoint}")
        print(f"ROLE_MAP1: {self.role_map1}")

        if not self.role_map1:
            raise ValueError("ROLE_MAP1 is required and missing.")

        if not all([self.region, self.opensearch_endpoint]):
            raise ValueError("Required environment variables are missing (region or OpenSearch endpoint).")

class LambdaHandler:
    def __init__(self, config):
        self.config = config

    def handle(self):
        """Main handling logic for mapping roles."""
        # Print only important roles and actions being taken
        if not self.config.arn_roles:
            print("No additional ROLE_MAPs provided. Proceeding with mapping for ROLE_MAP1 only.")

        # Assuming the role and getting credentials
        sts_client = STSClient(region=self.config.region)
        credentials = sts_client.assume_role(
            role_arn=self.config.role_map1,
            session_name="AssumeRoleSession"
        )

        # Use the extracted credentials for AWS4Auth
        service = 'es'
        awsauth = AWS4Auth(credentials['AccessKeyId'], credentials['SecretAccessKey'], self.config.region, service, session_token=credentials['SessionToken'])

        # Strip protocol from endpoint
        domain_endpoint = self.config.opensearch_endpoint.split('//')[-1]
        print(f"Mapping roles to OpenSearch domain: {domain_endpoint}")

        # Map roles
        opensearch_client = OpenSearchClient(domain_endpoint, awsauth)
        role_mapper = RoleMapper(opensearch_client)
        response, updated_roles = role_mapper.map_roles("all_access", self.config.arn_roles)

        # Check for success and validation
        if response.get('status') == 'OK':
            print("Roles successfully mapped to 'all_access'. Verifying roles...")
            final_roles = opensearch_client.get_current_roles("all_access")
            if set(final_roles) == set(updated_roles):
                print("Role mapping validation successful.")
                return {
                    'statusCode': 200,
                    'body': 'Roles added to all_access role mapping successfully and validated.'
                }
            else:
                print("Validation failed: Role mapping mismatch.")
                return {
                    'statusCode': 500,
                    'body': 'Roles added but validation failed due to mismatch.'
                }

        print("Role mapping failed.")
        return {
            'statusCode': 500,
            'body': 'Failed to map roles to all_access.'
        }

def lambda_handler(event, context):
    """Main Lambda handler function."""
    try:
        config = EnvironmentConfig()
        handler = LambdaHandler(config)
        return handler.handle()
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': f"Execution failed due to: {str(e)}"
        }

if __name__ == "__main__":
    lambda_handler(None, None)