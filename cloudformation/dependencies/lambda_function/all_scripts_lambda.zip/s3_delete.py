import json
import boto3
import logging
import os
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def chunk_list(iterable, chunk_size=1000):
    """Yield successive chunks of size chunk_size from iterable."""
    for i in range(0, len(iterable), chunk_size):
        yield iterable[i:i + chunk_size]

# === S3DeletionHelper: Handles emptying and deleting an individual bucket ===
class S3DeletionHelper:
    def __init__(self, s3_client):
        self.s3_client = s3_client

    def empty_bucket(self, bucket_name):
        try:
            logger.info(f"Emptying bucket: {bucket_name}")
            paginator = self.s3_client.get_paginator('list_object_versions')
            for page in paginator.paginate(Bucket=bucket_name):
                delete_markers = page.get('DeleteMarkers', [])
                versions = page.get('Versions', [])

                # Combine versions and delete markers.
                objects_to_delete = [
                    {'Key': obj['Key'], 'VersionId': obj['VersionId']}
                    for obj in delete_markers + versions
                ]

                # AWS delete_objects supports max 1000 objects per request.
                if objects_to_delete:
                    for batch in chunk_list(objects_to_delete, 1000):
                        self.s3_client.delete_objects(
                            Bucket=bucket_name,
                            Delete={'Objects': batch}
                        )
                        logger.info(f"Deleted a batch of {len(batch)} objects from {bucket_name}")
                else:
                    logger.info(f"No objects to delete in bucket: {bucket_name}")
        except ClientError as e:
            logger.error(f"Error emptying bucket {bucket_name}: {e.response['Error']['Message']}")
            raise

    def delete_bucket(self, bucket_name):
        try:
            self.empty_bucket(bucket_name)
            logger.info(f"Deleting bucket: {bucket_name}")
            self.s3_client.delete_bucket(Bucket=bucket_name)
            logger.info(f"Bucket {bucket_name} deleted successfully.")
            return True
        except ClientError as e:
            logger.error(f"Error deleting bucket {bucket_name}: {e.response['Error']['Message']}")
            return False

# === S3BucketFilter: Filters S3 buckets based on tags ===
class S3BucketFilter:
    def __init__(self, s3_client):
        self.s3_client = s3_client

    def get_buckets_by_tag(self, tag_key, tag_value):
        matching_buckets = []
        try:
            buckets_response = self.s3_client.list_buckets()
            buckets = buckets_response.get('Buckets', [])
            logger.info(f"Found {len(buckets)} buckets total.")

            for bucket in buckets:
                bucket_name = bucket['Name']
                try:
                    tagging = self.s3_client.get_bucket_tagging(Bucket=bucket_name)
                    tags = {tag['Key']: tag['Value'] for tag in tagging.get('TagSet', [])}
                    if tags.get(tag_key) == tag_value:
                        matching_buckets.append(bucket_name)
                        logger.info(f"Bucket '{bucket_name}' matches tag filter ({tag_key}: {tag_value})")
                    else:
                        logger.debug(f"Bucket '{bucket_name}' does not match tag filter.")
                except self.s3_client.exceptions.ClientError as e:
                    error_code = e.response['Error']['Code']
                    if error_code == 'NoSuchTagSet':
                        logger.debug(f"Bucket '{bucket_name}' has no tags.")
                    else:
                        logger.warning(f"Could not retrieve tags for bucket '{bucket_name}': {e.response['Error']['Message']}")
            return matching_buckets

        except ClientError as e:
            logger.error(f"Error listing buckets: {e.response['Error']['Message']}")
            raise

# === S3DeletionManager: Orchestrates parallel deletion of buckets ===
class S3DeletionManager:
    def __init__(self, s3_client):
        self.s3_client = s3_client
        self.deletion_helper = S3DeletionHelper(s3_client)
        self.bucket_filter = S3BucketFilter(s3_client)

    def run_deletion(self, tag_key, tag_value, max_workers=10):
        buckets_to_delete = self.bucket_filter.get_buckets_by_tag(tag_key, tag_value)
        if not buckets_to_delete:
            logger.info(f"No buckets found with tag ({tag_key}: {tag_value})")
            return {
                "message": f"No buckets found with tag ({tag_key}: {tag_value}).",
                "deleted_buckets": []
            }

        results = {}
        # Use ThreadPoolExecutor to delete buckets in parallel.
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_bucket = {
                executor.submit(self.deletion_helper.delete_bucket, bucket): bucket
                for bucket in buckets_to_delete
            }
            for future in as_completed(future_to_bucket):
                bucket = future_to_bucket[future]
                try:
                    success = future.result()
                    results[bucket] = "Deleted" if success else "Failed"
                except Exception as exc:
                    logger.error(f"Bucket {bucket} generated an exception: {exc}")
                    results[bucket] = f"Exception: {exc}"

        return {
            "message": f"Attempted deletion of {len(buckets_to_delete)} buckets with tag ({tag_key}: {tag_value}).",
            "results": results
        }

# === Lambda Handler ===
def lambda_handler(event, context):
    # Read tag filter from environment variables.
    tag_key = os.getenv('TAG_KEY')
    tag_value = os.getenv('TAG_VALUE')

    if not tag_key or not tag_value:
        error_message = "Environment variables 'TAG_KEY' and 'TAG_VALUE' are required."
        logger.error(error_message)
        return {
            "statusCode": 400,
            "body": json.dumps({"error": error_message})
        }

    s3_client = boto3.client('s3')
    deletion_manager = S3DeletionManager(s3_client)

    try:
        result = deletion_manager.run_deletion(tag_key, tag_value)
        return {
            "statusCode": 200,
            "body": json.dumps(result)
        }
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
