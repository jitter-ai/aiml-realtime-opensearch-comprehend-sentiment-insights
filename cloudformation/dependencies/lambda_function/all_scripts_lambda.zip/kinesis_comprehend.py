import json
import boto3
import base64
import os

comprehend = boto3.client('comprehend')
kinesis = boto3.client('kinesis')

def lambda_handler(event, context):
    output_stream = os.environ['OUTPUT_STREAM']

    for record in event['Records']:
        # Decode the Kinesis data
        payload = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        data = json.loads(payload)

        # Get feedback text and detect sentiment
        feedback_text = data.get('feedback', '')
        if feedback_text:
            sentiment_response = comprehend.detect_sentiment(
                Text=feedback_text,
                LanguageCode='en'
            )

            # Add sentiment data to original record
            data['sentiment'] = sentiment_response['Sentiment']
            data['sentiment_score'] = sentiment_response['SentimentScore']

        # Put enriched data to output stream
        kinesis.put_record(
            StreamName=output_stream,
            Data=json.dumps(data),
            PartitionKey='partition-key'
        )

    return {
        'statusCode': 200,
        'body': json.dumps('Processing completed successfully!')
    }
