import boto3
import os

def create_cognito_user():
    username = os.environ['USERNAME']
    password = os.environ['PASSWORD']
    user_pool_id = os.environ['USER_POOL_ID']

    client = boto3.client('cognito-idp')

    response = {}
    try:
        client.admin_create_user(
            UserPoolId=user_pool_id,
            Username=username,
            TemporaryPassword=password
        )
        response['Message'] = 'User created successfully'
    except Exception as e:
        response['Message'] = f"An error occurred: {str(e)}"
    return response

def handler(event, context):
    try:
        return create_cognito_user()
    except Exception as e:
        print(f"Failed to process: {e}")
        return {
            'Message': f"An error occurred: {str(e)}"
        }
