import json
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
import boto3
import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    sts = boto3.client('sts')
    assumed_role = sts.assume_role(
        RoleArn=os.environ['AOS_AUTH_ROLE'],
        RoleSessionName="AssumeTimRoleSession"
    )

    access_key = assumed_role['Credentials']['AccessKeyId']
    secret_key = assumed_role['Credentials']['SecretAccessKey']
    session_token = assumed_role['Credentials']['SessionToken']

    service = 'es'
    region = os.environ.get('LAMBDA_REGION')
    awsauth = AWS4Auth(access_key, secret_key, region, service, session_token=session_token)
    domain_endpoint = os.environ.get('OPENSEARCH_ENDPOINT')

    es = OpenSearch(
        hosts=[{'host': domain_endpoint, 'port': 443}],
        http_auth=awsauth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection
    )

    # Create an index template for future survey data indexes
    template_name = "survey_data_logs"
    template_body = {
        "index_patterns": ["survey-data*"],
        "template": {
            "aliases": {
                "survey-data-alias": {}
            },
            "settings": {
                "number_of_shards": 2,
                "number_of_replicas": 1
            },
            "mappings": {
                "properties": {
                    "submitted_on": {
                        "type": "date",
                        "format": "yyyy-MM-dd'T'HH:mm:ss'Z'||yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_millis"
                    }
                }
            }
        }
    }

    try:
        es.indices.put_template(name=template_name, body=template_body)
    except Exception as e:
        logger.error(f"Error creating index template: {str(e)}")
        return {
            'statusCode': 500,
            'body': f"Error creating index template: {str(e)}"
        }

    return {
        'statusCode': 200,
        'body': f'Index template "{template_name}" created successfully'
    }

